(function(){
  var PHONE = "255653408635";

  // mobile menu
  var btn = document.getElementById("menuBtn");
  var panel = document.getElementById("mobileNav");
  if(btn && panel){
    btn.addEventListener("click", function(){
      var open = panel.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  // WhatsApp inquiry form (no server: it opens WhatsApp with the message ready)
  var form = document.getElementById("askForm");
  if(form){
    form.addEventListener("submit", function(e){
      e.preventDefault();
      var name = document.getElementById("f-name");
      if(!name.value.trim()){ name.focus(); alert(form.dataset.needName); return; }
      var area = document.getElementById("f-area");
      var areaText = area.options[area.selectedIndex].textContent;
      var msg = document.getElementById("f-msg").value.trim();
      var text = form.dataset.hello + "\n" + form.dataset.lName + ": " + name.value.trim() +
                 "\n" + form.dataset.lArea + ": " + areaText +
                 (msg ? "\n" + form.dataset.lMsg + ": " + msg : "");
      window.open("https://wa.me/" + PHONE + "?text=" + encodeURIComponent(text), "_blank", "noopener");
    });
  }
})();
